export enum ContinentType {
  AFRICAN = 'african',
  CARIBBEAN = 'caribbean',
  ASIAN = 'asian',
}
