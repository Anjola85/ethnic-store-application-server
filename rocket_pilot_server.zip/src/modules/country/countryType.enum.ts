export enum CountryType {
  NIGERIAN = 'nigeria',
  GHANA = 'ghana',
}
