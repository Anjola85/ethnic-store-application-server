export enum CategoryType {
  GROCERY = 'grocery',
  RESTAURANT = 'restaurant',
  SERVICE = 'service',
}
