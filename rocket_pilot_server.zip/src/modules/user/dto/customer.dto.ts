// import { PersonDTO } from './person.dto';

// export class CustomerDto extends PersonDTO {}
