export enum UserProfile {
  MERCHANT = 'merchant',
  CUSTOMER = 'customer',
}
